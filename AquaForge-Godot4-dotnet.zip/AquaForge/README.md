# AquaForge — água para jogos (Godot 4 .NET)

Sistema técnico para água e terreno costeiro em Godot 4 .NET. Usa o **Waterways .NET** como gerador/fonte de fluxo para rios e permite substituir o material oceânico pelo **Boujie Water Shader**. Inclui terreno procedural deformável: ondas e corrente alteram lentamente a batimetria, espalham humidade pela areia, deixam a superfície mais escura/brilhante e geram uma franja de espuma de recuo. A demo combina praia, lago, colisores deformáveis e corpo flutuante.

> As extensões originais são projetos Godot, não Unity. O Waterways .NET atual gera malha de rio/fluxo e expõe `GetWaterHeight` e `GetWaterFlowDirection` no FloatSystem; o Boujie fornece shader oceânico com ondas Gerstner, Fresnel, espuma e LOD. AquaForge integra as consultas e oferece um modo visual de fallback de menor custo. Consulte as licenças e notas de cada projeto antes de distribuir.

## Abrir a demo

1. Instale **Godot 4 .NET** (runtime .NET 8) e abra `project.godot`.
2. As pastas dos dois addons já vêm em `addons/` (fontes e licenças; demos e histórico Git foram omitidos). Para atualizar/reinstalar, execute `scripts/install_addons.sh`.
3. No Godot: **Project > Tools > C# > Create C# solution** (se necessário); compile a solução e reabra o editor. Os plugins WaterwaysNet e Boujie já vêm habilitados em `project.godot`.
4. Execute `scenes/main.tscn`. A cena contém um lago sintético e um corpo rígido de demonstração.

Dependências open source incluídas (upstream):
- Waterways .NET: `addons/waterways_net` — https://github.com/Tshmofen/waterways-net
- Boujie Water Shader: `addons/boujie_water_shader` — https://github.com/Chrisknyfe/boujie_water_shader

## Configurar rios

1. Crie um `RiverManager` usando a ferramenta do Waterways e desenhe o curso Bézier; ajuste larguras, subdivisões e suavização conforme a escala do cenário.
2. Adicione um `RiverFloatSystem` como filho do `RiverManager` (é o nome da classe/nó no addon) e configure a camada de colisão de água sem interferir com os demais raycasts.
3. Adicione `WaterwaysRiverAdapter` à cena. Em `FloatSystemPath`, arraste o nó `RiverFloatSystem`. Defina `DefaultHeight` do plugin para o mesmo valor de `MissHeight` do adapter (padrão `-10000`).
4. Corpos flutuantes usam `BuoyantBody3D`; configure `WaterWorldPath` para o nó `WaterWorld` e ajuste `HalfExtents`, `SampleGrid` e `Buoyancy`.

A ponte usa os nomes públicos descritos pelo Waterways .NET (`GetWaterHeight` e `GetWaterFlowDirection`) e não compila dependência direta contra classes internas do addon. O FloatSystem precisa estar na cena e corretamente configurado para consultas válidas.

## Configurar lagos e praias

Adicione `WaterBody3D` como filho da cena. Escolha `Kind` (`Lake`, `Ocean` ou `Beach`), configure `Bounds`, `SurfaceOffset`, ondas e vetor/velocidade de fluxo. Para física sensível ao relevo, mantenha colisores no terreno (HeightMap, mesh estática, terreno voxel etc.) e configure `WaterWorld.TerrainCollisionMask` para as layers do leito/margens. O raycast exclui o próprio corpo flutuante, usa cache espacial dentro de cada passo físico e volta a medir no passo seguinte: bancos elevados cortam a água, profundidade rasa reduz o empuxo e o arrasto, e mudanças de colisores são percebidas em tempo de jogo. Use uma layer dedicada ao terreno — não inclua corpos móveis nessa máscara — para evitar que objetos flutuantes sejam confundidos com o fundo. Se `TerrainCollisionMask = 0`, a zona volta ao modo de água profunda sem batimetria.

O shader cobre o visual da água; a consulta física usa ondas analíticas econômicas e batimetria por colisão. A malha visual da água não é recortada automaticamente pelo terreno; a adaptação do relevo acontece na física e no material da areia.

### Terreno que responde à água

Adicione `ErodibleTerrain3D` à cena para gerar um perfil de bacia + praia com malha e colisor próprios. A cada intervalo, o sistema compara a altura do leito com as ondas/correntes ativas: remove uma pequena quantidade de sedimento na faixa de arrebentação e pode depositar parte a jusante. A umidade sobe rapidamente quando a onda alcança a areia e seca lentamente quando a água recua. `wet_sand.gdshader` usa esse canal de umidade para escurecer a areia, reduzir rugosidade e desenhar uma faixa irregular de espuma.

Parâmetros principais: `GridResolution` controla detalhe/custo; `ErosionRate` e `MaxErosionDepth` limitam erosão; `BeachRunup`/`WetSandBand` definem o alcance do espraiamento; `WettingRate`/`DryingRate` controlam a persistência; `SimulationInterval` e `CollisionUpdateInterval` escalonam malha e colisão. O preset da demo usa uma grade 64×64. O colisor é reconstruído com menos frequência que a malha visual para manter custo adequado em dispositivos intermediários. A taxa de erosão é intencionalmente lenta em jogo normal; aumente-a para testes ou para uma cena estilizada.

O efeito é uma aproximação de jogo baseada em altura, velocidade das ondas e colisores — não uma simulação CFD/granular. Para terrenos externos, mantenha o componente de colisão atualizado e configure `WaterWorld.TerrainCollisionMask`; a deformação de malha automática é feita pelo `ErodibleTerrain3D`.

Para usar o **Boujie Water Shader** em vez do shader leve, atribua o material do addon ao campo `SurfaceMaterial` da área oceânica. O plugin Boujie tem sua própria malha oceânica/LOD; em projetos de produção, prefira usar o seu nó Ocean e deixe `WaterBody3D.BuildVisualSurface = false` para evitar duas superfícies sobrepostas. O shader AquaForge permanece como fallback de baixo custo.

## Desempenho e qualidade

- Projeto usa renderer `mobile`; a superfície padrão é uma malha subdividida modesta e não depende de refração de tela, SSR ou simulação GPU.
- `BuoyantBody3D` amostra uma grade pequena e aplica forças por ponto; comece com 3×3 ou 4×4 por objeto. Aumente amostras só em barcos grandes.
- Configure `SampleGrid` e número de corpos físicos conforme profiling; evite centenas de corpos flutuantes ativos.
- Use o LOD/fade do Boujie em oceanos abertos, limite espuma e ondas detalhadas à proximidade da câmera e reduza sombras em Android intermediário.
- Física não substitui colisores: rios do Waterways precisam de `FloatSystem` e configuração de layer/raycast; para lagos, a solução é uma superfície plana com ondas aproximadas.

## Estrutura

- `scripts/WaterWorld.cs`: busca a superfície de água mais alta entre corpos e rios.
- `scripts/WaterwaysRiverAdapter.cs`: ponte fracamente acoplada para o FloatSystem.
- `scripts/WaterBody3D.cs`: zona de água local, ondas baratas e fluxo.
- `scripts/BuoyantBody3D.cs`: empuxo distribuído e arrasto.
- `scripts/ErodibleTerrain3D.cs`: perfil costeiro, erosão/deposição simplificadas, umidade e atualização de colisão.
- `shaders/water_mobile.gdshader`: água econômica; `shaders/wet_sand.gdshader`: areia molhada e espuma de recuo.
- `scripts/Main.cs`: demo com terreno deformável gerado por código.

## Validação neste ambiente

Testado com Godot 4.3 .NET e .NET 8: a solução compila com 0 erros (38 avisos de nulabilidade vêm do código upstream Waterways) e a cena principal roda em headless por 180 frames. As cenas de regressão passaram nos sete checks de física e costa: leito profundo, corpo rígido que flutua, redução de empuxo em água rasa, margem seca após mover o terreno, erosão mensurável em 5 s simulados, colisor sincronizado com o relevo e umidade persistente no alcance das ondas.

## Teste automático de batimetria

As cenas headless `tests/terrain_physics_test.tscn` e `tests/shore_deformation_test.tscn` cobrem a física, a alteração do perfil e a umidade da areia. Execute na raiz com Godot 4 .NET após compilar:

```sh
godot --headless --path . res://tests/terrain_physics_test.tscn
godot --headless --path . res://tests/shore_deformation_test.tscn
```

## Licenças / atribuição

Waterways .NET e Boujie Water Shader são dependências open source independentes. Consulte as licenças que vêm nos seus repositórios (`LICENSE` e `LICENSE.md`) e preserve atribuição/avisos ao redistribuir. O código novo deste starter é disponibilizado sob MIT (veja `LICENSE`).
