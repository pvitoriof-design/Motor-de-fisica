#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p addons
if [ ! -f addons/waterways_net/plugin.cfg ]; then
  git clone --depth 1 https://github.com/Tshmofen/waterways-net.git /tmp/aquaforge-waterways
  mkdir -p addons/waterways_net
  cp -a /tmp/aquaforge-waterways/addons/waterways_net/. addons/waterways_net/
  cp /tmp/aquaforge-waterways/LICENSE addons/waterways_net/LICENSE.upstream
  rm -rf /tmp/aquaforge-waterways
fi
if [ ! -f addons/boujie_water_shader/plugin.cfg ]; then
  git clone --depth 1 https://github.com/Chrisknyfe/boujie_water_shader.git /tmp/aquaforge-boujie
  mkdir -p addons/boujie_water_shader
  cp -a /tmp/aquaforge-boujie/addons/boujie_water_shader/. addons/boujie_water_shader/
  rm -rf /tmp/aquaforge-boujie
fi
printf '\nAddons presentes. Abra em Godot 4 .NET, crie/atualize a solução C# e compile.\n'
