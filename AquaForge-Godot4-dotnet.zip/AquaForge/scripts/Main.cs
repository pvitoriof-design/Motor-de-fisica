using Godot;

namespace AquaForge;

public partial class Main : Node3D
{
    public override void _Ready()
    {
        var environment = new WorldEnvironment
        {
            Environment = new Environment
            {
                BackgroundMode = Environment.BGMode.Color,
                BackgroundColor = new Color("#a8d9e8"),
                AmbientLightSource = Environment.AmbientSource.Color,
                AmbientLightColor = new Color("#d8f3ff"),
                AmbientLightEnergy = 0.65f,
                TonemapMode = Environment.ToneMapper.Filmic
            }
        };
        AddChild(environment);

        var sun = new DirectionalLight3D { RotationDegrees = new Vector3(-48, -28, 0), ShadowEnabled = true, LightEnergy = 1.2f };
        AddChild(sun);

        var waterWorld = new WaterWorld { Name = "WaterWorld" };
        AddChild(waterWorld);

        var lake = new WaterBody3D
        {
            Name = "Lake",
            Kind = WaterBody3D.WaterKind.Lake,
            Bounds = new Vector2(44, 44),
            WaveHeight = 0.32f,
            WaveLength = 6.5f,
            WaveSpeed = 1.15f,
            FlowDirection = new Vector3(1, 0, 0.25f),
            FlowSpeed = 0.14f
        };
        AddChild(lake);

        // Praia/terreno procedural deformável com malha visual e colisor atualizáveis.
        AddChild(new ErodibleTerrain3D
        {
            Name = "ErodibleShoreTerrain",
            TerrainSize = new Vector2(60, 60),
            GridResolution = 64,
            BasinDepth = 3.5f,
            ShorelineRadius = 18f,
            OuterBeachRadius = 27f,
            BeachRise = 1.45f,
            ErosionRate = 0.008f,
            BeachRunup = 0.55f,
            WetSandBand = 0.8f,
            SimulationInterval = 0.2f,
            CollisionUpdateInterval = 0.65f
        });

        var floating = new RigidBody3D { Name = "FloatingCrate", Position = new Vector3(0, 1.5f, 0), Mass = 18f, ContinuousCd = true };
        floating.AddToGroup("buoyant_objects");
        var box = new MeshInstance3D { Mesh = new BoxMesh { Size = new Vector3(1.2f, 0.7f, 1.2f) } };
        box.MaterialOverride = new StandardMaterial3D { AlbedoColor = new Color("#b8753d"), Roughness = 0.82f };
        floating.AddChild(box);
        var collider = new CollisionShape3D { Shape = new BoxShape3D { Size = new Vector3(1.2f, 0.7f, 1.2f) } };
        floating.AddChild(collider);
        floating.AddChild(new BuoyantBody3D { Name = "Buoyancy", WaterWorldPath = new NodePath("../../WaterWorld"), HalfExtents = new Vector3(0.55f, 0.3f, 0.55f) });
        AddChild(floating);

        var camera = new Camera3D { Name = "Camera3D", Position = new Vector3(17, 17, 22), Current = true, Fov = 52f };
        AddChild(camera);
        camera.LookAt(new Vector3(0, 0, 0), Vector3.Up);
    }

}
