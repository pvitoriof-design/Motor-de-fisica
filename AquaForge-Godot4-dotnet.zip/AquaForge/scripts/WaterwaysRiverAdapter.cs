using Godot;
using System.Collections.Generic;

namespace AquaForge;

/// <summary>
/// Ponte opcional para o FloatSystem do Waterways .NET. Aponte FloatSystemPath
/// para o nó FloatSystem da extensão. Configure DefaultHeight do plugin para MissHeight.
/// </summary>
[GlobalClass]
public partial class WaterwaysRiverAdapter : Node
{
    private static readonly List<WaterwaysRiverAdapter> LiveAdapters = new();
    public static IReadOnlyList<WaterwaysRiverAdapter> Adapters => LiveAdapters;

    [Export] public NodePath FloatSystemPath { get; set; } = new();
    [Export] public float MissHeight { get; set; } = -10000f;
    [Export] public float MaxSampleDistance { get; set; } = 100f;
    private Node? _floatSystem;

    public override void _Ready()
    {
        _floatSystem = GetNodeOrNull(FloatSystemPath);
        if (!LiveAdapters.Contains(this)) LiveAdapters.Add(this);
        AddToGroup("aquaforge_river_adapters");
        if (_floatSystem == null)
            GD.PushWarning($"{Name}: FloatSystemPath não aponta para um FloatSystem válido.");
    }

    public override void _ExitTree() => LiveAdapters.Remove(this);

    public bool TrySample(Vector3 worldPosition, out float height, out Vector3 flow)
    {
        height = MissHeight;
        flow = Vector3.Zero;
        if (_floatSystem == null) return false;
        try
        {
            // Métodos documentados pelo Waterways .NET: GetWaterHeight e GetWaterFlowDirection.
            height = (float)_floatSystem.Call("GetWaterHeight", worldPosition).AsDouble();
            if (Mathf.IsEqualApprox(height, MissHeight) || Mathf.Abs(height - worldPosition.Y) > MaxSampleDistance) return false;
            flow = _floatSystem.Call("GetWaterFlowDirection", worldPosition).AsVector3();
            return true;
        }
        catch (System.Exception e)
        {
            GD.PushWarning($"Falha ao consultar Waterways FloatSystem: {e.Message}");
            return false;
        }
    }
}
