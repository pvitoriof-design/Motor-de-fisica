using Godot;
using System.Collections.Generic;

namespace AquaForge;

public struct WaterSample
{
    public float Height;
    public Vector3 Flow;
    public float Depth;       // Distância entre a superfície e o terreno abaixo.
    public float WetFactor;   // Atenua forças no raso e junto à linha d'água.
    public WaterBody3D? Body;
    public bool IsRiver;
}

/// <summary>
/// Consulta unificada de rios e zonas de água. Usa raycasts na camada de terreno
/// para detectar margens, bancos rasos e alterações de terreno em tempo de jogo.
/// </summary>
[GlobalClass]
public partial class WaterWorld : Node3D
{
    [Export(PropertyHint.Layers3DPhysics)] public uint TerrainCollisionMask { get; set; } = 1;
    [Export(PropertyHint.Range, "1,100,1")] public float TerrainProbeUp { get; set; } = 30f;
    [Export(PropertyHint.Range, "5,300,1")] public float TerrainProbeDepth { get; set; } = 60f;
    [Export(PropertyHint.Range, "0.01,5,0.01")] public float TerrainCacheCellSize { get; set; } = 0.75f;
    [Export(PropertyHint.Range, "0,2,0.01")] public float MinimumWaterDepth { get; set; } = 0.12f;
    [Export(PropertyHint.Range, "0.05,5,0.05")] public float ShoreFadeDepth { get; set; } = 0.9f;

    private readonly Dictionary<(int X, int Z, string ExcludedRid), float?> _terrainCache = new();

    public override void _PhysicsProcess(double delta)
    {
        // Atualiza o cache a cada passo físico. Alterações em HeightMap/colisores
        // aparecem no passo seguinte, sem acumular amostras obsoletas.
        _terrainCache.Clear();
    }

    public bool TrySample(Vector3 position, out WaterSample sample, Rid? excludedBody = null)
    {
        sample = default;
        var bestHeight = float.NegativeInfinity;
        var found = false;
        var now = (float)Time.GetTicksMsec() / 1000f;

        foreach (var river in WaterwaysRiverAdapter.Adapters)
        {
            if (!GodotObject.IsInstanceValid(river)) continue;
            if (!river.TrySample(position, out var height, out var flow) || height > position.Y + 2f) continue;
            if (!TryBuildSample(position, height, flow, null, true, excludedBody, out var candidate)) continue;
            if (candidate.Height > bestHeight)
            {
                bestHeight = candidate.Height;
                sample = candidate;
                found = true;
            }
        }

        foreach (var body in WaterBody3D.Bodies)
        {
            if (!GodotObject.IsInstanceValid(body) || !body.ContainsXZ(position)) continue;
            var height = body.GetSurfaceHeight(position, now);
            if (height > position.Y + 2f) continue;
            if (!TryBuildSample(position, height, body.GetFlowWorld(), body, false, excludedBody, out var candidate)) continue;
            if (candidate.Height > bestHeight)
            {
                bestHeight = candidate.Height;
                sample = candidate;
                found = true;
            }
        }
        return found;
    }

    private bool TryBuildSample(Vector3 position, float surfaceHeight, Vector3 flow, WaterBody3D? body,
        bool isRiver, Rid? excludedBody, out WaterSample sample)
    {
        sample = default;
        var depth = float.PositiveInfinity;
        var wetFactor = 1f;
        if (TerrainCollisionMask != 0 && TryGetTerrainHeight(position, surfaceHeight, excludedBody, out var bedHeight))
        {
            depth = surfaceHeight - bedHeight;
            // Terreno acima da água ou uma lâmina praticamente seca: não é água navegável.
            if (depth <= MinimumWaterDepth) return false;
            wetFactor = Mathf.Clamp((depth - MinimumWaterDepth) / Mathf.Max(ShoreFadeDepth, 0.01f), 0f, 1f);
            wetFactor = wetFactor * wetFactor * (3f - 2f * wetFactor); // smoothstep sem custo de shader
        }
        sample = new WaterSample
        {
            Height = surfaceHeight,
            Flow = flow,
            Depth = depth,
            WetFactor = wetFactor,
            Body = body,
            IsRiver = isRiver
        };
        return true;
    }

    /// <summary>Consulta a altura do terreno sob uma coordenada usando a máscara configurada.</summary>
    public bool TryGetTerrainHeight(Vector3 worldPosition, float referenceWaterHeight, Rid? excludedBody, out float terrainHeight)
    {
        terrainHeight = 0f;
        if (TerrainCollisionMask == 0 || GetWorld3D() == null) return false;
        var cell = Mathf.Max(TerrainCacheCellSize, 0.01f);
        var cellX = Mathf.FloorToInt(worldPosition.X / cell);
        var cellZ = Mathf.FloorToInt(worldPosition.Z / cell);
        var ridId = excludedBody.HasValue ? excludedBody.Value.ToString() : string.Empty;
        var key = (cellX, cellZ, ridId);
        if (_terrainCache.TryGetValue(key, out var cached))
        {
            if (!cached.HasValue) return false;
            terrainHeight = cached.Value;
            return true;
        }

        var from = new Vector3(worldPosition.X, referenceWaterHeight + TerrainProbeUp, worldPosition.Z);
        var to = new Vector3(worldPosition.X, referenceWaterHeight - TerrainProbeDepth, worldPosition.Z);
        var query = PhysicsRayQueryParameters3D.Create(from, to);
        query.CollisionMask = TerrainCollisionMask;
        query.CollideWithAreas = false;
        query.CollideWithBodies = true;
        if (excludedBody.HasValue)
            query.Exclude = new Godot.Collections.Array<Rid> { excludedBody.Value };

        var result = GetWorld3D().DirectSpaceState.IntersectRay(query);
        if (result.Count == 0)
        {
            _terrainCache[key] = null;
            return false; // sem colisão abaixo: tratar como água profunda
        }
        terrainHeight = result["position"].AsVector3().Y;
        _terrainCache[key] = terrainHeight;
        return true;
    }
}
