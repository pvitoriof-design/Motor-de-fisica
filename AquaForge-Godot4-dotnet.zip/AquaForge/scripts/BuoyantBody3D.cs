using Godot;

namespace AquaForge;

/// <summary>
/// Empuxo em uma grade de pontos. A fração submersa é limitada pela profundidade
/// real do terreno sob cada ponto; margens rasas deixam de sustentar o objeto.
/// </summary>
[GlobalClass]
public partial class BuoyantBody3D : Node
{
    [Export] public RigidBody3D? TargetBody { get; set; }
    [Export] public NodePath WaterWorldPath { get; set; } = new("../WaterWorld");
    [Export] public Vector3 HalfExtents { get; set; } = new(0.6f, 0.35f, 0.6f);
    [Export(PropertyHint.Range, "2,9,1")] public int SampleGrid { get; set; } = 4;
    [Export(PropertyHint.Range, "0.1,3,0.05")] public float Buoyancy { get; set; } = 1.15f;
    [Export(PropertyHint.Range, "0.1,12,0.05")] public float WaterDrag { get; set; } = 2.8f;
    [Export(PropertyHint.Range, "0,3,0.05")] public float FlowInfluence { get; set; } = 0.45f;
    [Export(PropertyHint.Range, "0.01,2,0.01")] public float FloatOffset { get; set; } = 0.05f;
    [Export(PropertyHint.Range, "0,0.5,0.01")] public float AirDrag { get; set; } = 0.035f;

    private WaterWorld? _waterWorld;
    private float _gravity = 9.8f;

    public override void _Ready()
    {
        if (TargetBody == null) TargetBody = GetParent() as RigidBody3D;
        _waterWorld = GetNodeOrNull<WaterWorld>(WaterWorldPath);
        var setting = ProjectSettings.GetSetting("physics/3d/default_gravity");
        if (setting.VariantType != Variant.Type.Nil) _gravity = (float)setting.AsDouble();
    }

    public override void _PhysicsProcess(double delta)
    {
        if (TargetBody == null || _waterWorld == null) return;
        var body = TargetBody;
        var n = Mathf.Clamp(SampleGrid, 2, 9);
        var count = n * n;
        var cellX = HalfExtents.X * 2f / (n - 1);
        var cellZ = HalfExtents.Z * 2f / (n - 1);
        var massShare = body.Mass / count;
        var excluded = body.GetRid();
        var activePoints = 0;

        for (var x = 0; x < n; x++)
        for (var z = 0; z < n; z++)
        {
            // Grade no fundo do casco, em vez de um único ponto central.
            var local = new Vector3(-HalfExtents.X + cellX * x, -HalfExtents.Y, -HalfExtents.Z + cellZ * z);
            var world = body.ToGlobal(local);
            if (!_waterWorld.TrySample(world, out var water, excluded)) continue;

            var hullHeight = Mathf.Max(HalfExtents.Y * 2f, 0.1f);
            var verticalSubmersion = Mathf.Clamp((water.Height + FloatOffset - world.Y) / hullHeight, 0f, 1f);
            // Água rasa não pode deslocar mais volume do que existe entre casco e leito.
            var terrainLimitedSubmersion = Mathf.Clamp(water.Depth / hullHeight, 0f, 1f);
            var submerged = Mathf.Min(verticalSubmersion, terrainLimitedSubmersion) * water.WetFactor;
            if (submerged <= 0.001f) continue;

            var pointVelocity = body.LinearVelocity + body.AngularVelocity.Cross(world - body.GlobalPosition);
            var gravity = _gravity * body.GravityScale;
            var buoyantForce = Vector3.Up * (gravity * massShare * Buoyancy * submerged);

            // Arrasto relativo: retira energia do movimento e tende à velocidade da corrente.
            var targetFlow = water.Flow * FlowInfluence;
            var relativeVelocity = targetFlow - pointVelocity;
            var dragForce = relativeVelocity * (WaterDrag * massShare * submerged);
            body.ApplyForce(buoyantForce + dragForce, world - body.GlobalPosition);
            activePoints++;
        }

        // Pequeno amortecimento fora d'água evita giros persistentes sem afetar a queda.
        if (activePoints == 0 && AirDrag > 0f)
            body.ApplyCentralForce(-body.LinearVelocity * (AirDrag * body.Mass));
    }
}
