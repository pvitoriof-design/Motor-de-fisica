using Godot;
using System;
using System.Collections.Generic;

namespace AquaForge;

/// <summary>Uma área de água plana (lago, mar ou praia) com consulta física barata.</summary>
[GlobalClass]
public partial class WaterBody3D : Node3D
{
    public enum WaterKind { Lake, Ocean, Beach }
    private static readonly List<WaterBody3D> LiveBodies = new();
    public static IReadOnlyList<WaterBody3D> Bodies => LiveBodies;

    [Export] public WaterKind Kind { get; set; } = WaterKind.Lake;
    [Export] public Vector2 Bounds { get; set; } = new(64f, 64f);
    [Export] public float SurfaceOffset { get; set; } = 0f;
    [Export] public float WaveHeight { get; set; } = 0.18f;
    [Export] public float WaveLength { get; set; } = 8f;
    [Export] public float WaveSpeed { get; set; } = 1f;
    [Export] public Vector3 FlowDirection { get; set; } = Vector3.Right;
    [Export(PropertyHint.Range, "0,8,0.05")] public float FlowSpeed { get; set; } = 0.2f;
    [Export] public bool FollowCamera { get; set; } = false;
    [Export] public Material? SurfaceMaterial { get; set; }
    [Export] public bool BuildVisualSurface { get; set; } = true;

    private MeshInstance3D? _surface;
    private ShaderMaterial? _generatedMaterial;

    public override void _Ready()
    {
        if (!LiveBodies.Contains(this)) LiveBodies.Add(this);
        AddToGroup("aquaforge_water_bodies");
        if (BuildVisualSurface) BuildSurface();
    }

    public override void _ExitTree() => LiveBodies.Remove(this);

    public override void _Process(double delta)
    {
        if (!FollowCamera || Kind != WaterKind.Ocean) return;
        var camera = GetViewport().GetCamera3D();
        if (camera == null) return;
        GlobalPosition = new Vector3(camera.GlobalPosition.X, GlobalPosition.Y, camera.GlobalPosition.Z);
    }

    private void BuildSurface()
    {
        var mesh = new PlaneMesh { Size = Bounds, SubdivideWidth = 32, SubdivideDepth = 32 };
        _surface = new MeshInstance3D { Name = "WaterSurface", Mesh = mesh, Position = new Vector3(0, SurfaceOffset, 0) };
        AddChild(_surface);
        if (SurfaceMaterial != null) _surface.MaterialOverride = SurfaceMaterial;
        else
        {
            var shader = GD.Load<Shader>("res://shaders/water_mobile.gdshader");
            if (shader != null)
            {
                _generatedMaterial = new ShaderMaterial { Shader = shader };
                _generatedMaterial.SetShaderParameter("wave_height", WaveHeight);
                _generatedMaterial.SetShaderParameter("wave_length", WaveLength);
                _generatedMaterial.SetShaderParameter("wave_speed", WaveSpeed);
                var direction = new Vector2(FlowDirection.X, FlowDirection.Z);
                if (direction.LengthSquared() < 0.0001f) direction = Vector2.Right;
                _generatedMaterial.SetShaderParameter("flow_direction", direction.Normalized());
                _surface.MaterialOverride = _generatedMaterial;
            }
        }
    }

    public bool ContainsXZ(Vector3 worldPosition)
    {
        var p = ToLocal(worldPosition);
        return Mathf.Abs(p.X) <= Bounds.X * 0.5f && Mathf.Abs(p.Z) <= Bounds.Y * 0.5f;
    }

    public float GetMeanSurfaceHeight() => ToGlobal(new Vector3(0, SurfaceOffset, 0)).Y;

    public float GetWaveOffsetAt(Vector3 worldPosition, float timeSeconds)
    {
        var p = ToLocal(worldPosition);
        var direction = new Vector2(FlowDirection.X, FlowDirection.Z);
        if (direction.LengthSquared() < 0.0001f) direction = Vector2.Right;
        direction = direction.Normalized();
        var phase = (p.X * direction.X + p.Z * direction.Y) * Mathf.Tau / Mathf.Max(WaveLength, 0.1f);
        var wave = Mathf.Sin(phase + timeSeconds * WaveSpeed) * WaveHeight;
        // Segunda direção, sincronizada com o shader visível e ainda sem textura/amostragem.
        var secondDirection = new Vector2(-direction.Y, direction.X) + new Vector2(0.24f, 0.12f);
        secondDirection = secondDirection.Normalized();
        var secondPhase = (p.X * secondDirection.X + p.Z * secondDirection.Y) * Mathf.Tau / Mathf.Max(WaveLength * 0.63f, 0.1f);
        wave += Mathf.Sin(secondPhase - timeSeconds * WaveSpeed * 0.73f) * WaveHeight * 0.22f;
        return wave;
    }

    public float GetSurfaceHeight(Vector3 worldPosition, float timeSeconds)
    {
        var p = ToLocal(worldPosition);
        return ToGlobal(new Vector3(p.X, SurfaceOffset + GetWaveOffsetAt(worldPosition, timeSeconds), p.Z)).Y;
    }

    public Vector3 GetFlowWorld()
    {
        var local = new Vector3(FlowDirection.X, 0, FlowDirection.Z);
        if (local.LengthSquared() < 0.0001f) local = Vector3.Right;
        return (GlobalBasis * local.Normalized()).Normalized() * FlowSpeed;
    }
}
