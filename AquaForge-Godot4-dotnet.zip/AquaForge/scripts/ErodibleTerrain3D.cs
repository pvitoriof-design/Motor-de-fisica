using Godot;
using System;

namespace AquaForge;

/// <summary>
/// Terreno costeiro procedural com deformação, transporte simplificado de sedimentos,
/// colisão atualizada e humidade persistente dirigida por ondas/correntes.
/// </summary>
[GlobalClass]
public partial class ErodibleTerrain3D : Node3D
{
    [Export] public Vector2 TerrainSize { get; set; } = new(60f, 60f);
    [Export(PropertyHint.Range, "16,160,1")] public int GridResolution { get; set; } = 64;
    [Export] public float BasinDepth { get; set; } = 3.5f;
    [Export] public float ShorelineRadius { get; set; } = 18f;
    [Export] public float OuterBeachRadius { get; set; } = 27f;
    [Export] public float BeachRise { get; set; } = 1.45f;
    [Export(PropertyHint.Range, "0,0.5,0.005")] public float MicroRelief { get; set; } = 0.045f;
    [Export(PropertyHint.Range, "0.1,20,0.1")] public float MaxErosionDepth { get; set; } = 1.4f;
    [Export(PropertyHint.Range, "0,0.05,0.0001")] public float ErosionRate { get; set; } = 0.008f;
    [Export(PropertyHint.Range, "0,1,0.01")] public float SedimentTransport { get; set; } = 0.18f;
    [Export(PropertyHint.Range, "0.05,5,0.05")] public float ErosionBand { get; set; } = 1.1f;
    [Export(PropertyHint.Range, "0.05,4,0.05")] public float BeachRunup { get; set; } = 0.5f;
    [Export(PropertyHint.Range, "0.05,4,0.05")] public float WetSandBand { get; set; } = 0.75f;
    [Export(PropertyHint.Range, "0.1,15,0.1")] public float WettingRate { get; set; } = 4f;
    [Export(PropertyHint.Range, "0.001,1,0.001")] public float DryingRate { get; set; } = 0.075f;
    [Export(PropertyHint.Range, "0.05,2,0.05")] public float SimulationInterval { get; set; } = 0.2f;
    [Export(PropertyHint.Range, "0.1,5,0.1")] public float CollisionUpdateInterval { get; set; } = 0.65f;
    [Export(PropertyHint.Range, "0.001,0.1,0.001")] public float CollisionHeightThreshold { get; set; } = 0.018f;
    [Export(PropertyHint.Layers3DPhysics)] public uint TerrainCollisionLayer { get; set; } = 1;
    [Export] public bool Simulate { get; set; } = true;

    private int _side;
    private float _cellX;
    private float _cellZ;
    private float[] _heights = Array.Empty<float>();
    private float[] _initialHeights = Array.Empty<float>();
    private float[] _wetness = Array.Empty<float>();
    private float[] _delta = Array.Empty<float>();
    private float[] _collisionHeights = Array.Empty<float>();
    private Vector3[] _vertices = Array.Empty<Vector3>();
    private Vector3[] _normals = Array.Empty<Vector3>();
    private Vector2[] _uvs = Array.Empty<Vector2>();
    private Color[] _colors = Array.Empty<Color>();
    private int[] _indices = Array.Empty<int>();
    private MeshInstance3D? _visual;
    private StaticBody3D? _staticBody;
    private CollisionShape3D? _collision;
    private ShaderMaterial? _material;
    private float _simulationClock;
    private float _collisionClock;
    private bool _collisionDirty = true;

    public override void _Ready()
    {
        GridResolution = Mathf.Clamp(GridResolution, 16, 160);
        _side = GridResolution + 1;
        _cellX = TerrainSize.X / GridResolution;
        _cellZ = TerrainSize.Y / GridResolution;
        var count = _side * _side;
        _heights = new float[count];
        _initialHeights = new float[count];
        _wetness = new float[count];
        _delta = new float[count];
        _collisionHeights = new float[count];
        _vertices = new Vector3[count];
        _normals = new Vector3[count];
        _uvs = new Vector2[count];
        _colors = new Color[count];
        _indices = new int[GridResolution * GridResolution * 6];

        BuildTopologyAndInitialHeight();
        CreateNodes();
        RefreshSurfaceMesh();
        RefreshCollisionShape();
    }

    /// <summary>Altura e humidade interpoladas para debug, gameplay e testes.</summary>
    public float GetHeightAtLocalXZ(float x, float z) => SampleGrid(_heights, x, z);
    public float GetMoistureAtLocalXZ(float x, float z) => SampleGrid(_wetness, x, z);

    private float SampleGrid(float[] values, float x, float z)
    {
        if (values.Length == 0) return 0f;
        var gx = Mathf.Clamp((x + TerrainSize.X * 0.5f) / Mathf.Max(_cellX, 0.001f), 0f, _side - 1f);
        var gz = Mathf.Clamp((z + TerrainSize.Y * 0.5f) / Mathf.Max(_cellZ, 0.001f), 0f, _side - 1f);
        var x0 = Mathf.FloorToInt(gx);
        var z0 = Mathf.FloorToInt(gz);
        var x1 = Mathf.Min(x0 + 1, _side - 1);
        var z1 = Mathf.Min(z0 + 1, _side - 1);
        var tx = gx - x0;
        var tz = gz - z0;
        var a = Mathf.Lerp(values[z0 * _side + x0], values[z0 * _side + x1], tx);
        var b = Mathf.Lerp(values[z1 * _side + x0], values[z1 * _side + x1], tx);
        return Mathf.Lerp(a, b, tz);
    }

    public override void _PhysicsProcess(double delta)
    {
        if (!Simulate || _heights.Length == 0) return;
        _simulationClock += (float)delta;
        _collisionClock += (float)delta;
        if (_simulationClock < SimulationInterval) return;
        var step = Mathf.Min(_simulationClock, 0.5f);
        _simulationClock = 0f;
        SimulateWaterContact(step);
        RefreshSurfaceMesh();

        if (_collisionDirty && _collisionClock >= CollisionUpdateInterval)
        {
            RefreshCollisionShape();
            _collisionClock = 0f;
        }
    }

    private void BuildTopologyAndInitialHeight()
    {
        var index = 0;
        for (var z = 0; z < _side; z++)
        for (var x = 0; x < _side; x++)
        {
            var px = -TerrainSize.X * 0.5f + x * _cellX;
            var pz = -TerrainSize.Y * 0.5f + z * _cellZ;
            var radius = new Vector2(px, pz).Length();
            var h = CreateBasinProfile(radius, px, pz);
            _heights[index] = h;
            _initialHeights[index] = h;
            _collisionHeights[index] = h;
            _uvs[index] = new Vector2((float)x / GridResolution, (float)z / GridResolution);
            _vertices[index] = new Vector3(px, h, pz);
            _normals[index] = Vector3.Up;
            _colors[index] = new Color(0, 0, 0, 1);
            index++;
        }

        var t = 0;
        for (var z = 0; z < GridResolution; z++)
        for (var x = 0; x < GridResolution; x++)
        {
            var a = z * _side + x;
            var b = a + 1;
            var c = a + _side;
            var d = c + 1;
            // Winding para normais apontadas para cima.
            _indices[t++] = a; _indices[t++] = c; _indices[t++] = b;
            _indices[t++] = b; _indices[t++] = c; _indices[t++] = d;
        }
    }

    private float CreateBasinProfile(float radius, float x, float z)
    {
        var noise = (Mathf.Sin(x * 0.37f + z * 0.16f) * Mathf.Sin(z * 0.31f - x * 0.11f)) * MicroRelief;
        var inner = ShorelineRadius * 0.58f;
        if (radius < inner) return -BasinDepth + noise;
        if (radius < ShorelineRadius)
        {
            var t = Smooth01((radius - inner) / Mathf.Max(ShorelineRadius - inner, 0.01f));
            return Mathf.Lerp(-BasinDepth, 0.02f, t) + noise;
        }
        if (radius < OuterBeachRadius)
        {
            var t = Smooth01((radius - ShorelineRadius) / Mathf.Max(OuterBeachRadius - ShorelineRadius, 0.01f));
            return Mathf.Lerp(0.02f, BeachRise, t) + noise;
        }
        var dune = Mathf.Sin(x * 0.18f) * Mathf.Sin(z * 0.21f) * MicroRelief * 2f;
        return BeachRise + dune;
    }

    private void CreateNodes()
    {
        _visual = new MeshInstance3D { Name = "DeformableSandSurface", CastShadow = GeometryInstance3D.ShadowCastingSetting.Off };
        AddChild(_visual);

        var shader = GD.Load<Shader>("res://shaders/wet_sand.gdshader");
        if (shader != null)
        {
            _material = new ShaderMaterial { Shader = shader };
            _visual.MaterialOverride = _material;
        }

        _staticBody = new StaticBody3D { Name = "DeformableTerrainCollision", CollisionLayer = TerrainCollisionLayer, CollisionMask = 0 };
        AddChild(_staticBody);
        _collision = new CollisionShape3D { Name = "TerrainShape" };
        _staticBody.AddChild(_collision);
    }

    private void SimulateWaterContact(float dt)
    {
        Array.Clear(_delta, 0, _delta.Length);
        var time = (float)Time.GetTicksMsec() / 1000f;
        var bodies = WaterBody3D.Bodies;
        for (var i = 0; i < _heights.Length; i++)
        {
            var x = _vertices[i].X;
            var z = _vertices[i].Z;
            var localCurrent = new Vector3(x, _heights[i], z);
            var worldCurrent = ToGlobal(localCurrent);
            var bestWet = 0f;
            var erosionForcing = 0f;
            var transportFlow = Vector3.Zero;
            var selectedSurface = 0f;
            var selectedMean = 0f;

            foreach (var water in bodies)
            {
                if (!GodotObject.IsInstanceValid(water) || !water.ContainsXZ(worldCurrent)) continue;
                var surface = water.GetSurfaceHeight(worldCurrent, time);
                var runup = BeachRunup + water.WaveHeight * 1.45f;
                var band = Mathf.Max(WetSandBand + runup, 0.05f);
                var wetTarget = Smooth01((surface + runup + WetSandBand - worldCurrent.Y) / band);
                if (wetTarget <= bestWet) continue;

                bestWet = wetTarget;
                selectedSurface = surface;
                selectedMean = water.GetMeanSurfaceHeight();
                transportFlow = water.GetFlowWorld();
                var waveWork = Mathf.Abs(water.GetWaveOffsetAt(worldCurrent, time));
                erosionForcing = 0.18f + waveWork * 1.25f + transportFlow.Length() * 0.65f;
            }

            var wetRate = bestWet > _wetness[i] ? WettingRate : DryingRate;
            var moistureLerp = 1f - Mathf.Exp(-wetRate * dt);
            _wetness[i] = Mathf.Lerp(_wetness[i], bestWet, moistureLerp);

            if (bestWet > 0.02f && ErosionRate > 0f)
            {
                var waterDistance = Mathf.Abs(selectedSurface - worldCurrent.Y);
                var shoreEnergy = 1f / (1f + waterDistance / Mathf.Max(ErosionBand, 0.05f));
                var lowerLimit = _initialHeights[i] - MaxErosionDepth;
                var erosion = Mathf.Min(Mathf.Max(_heights[i] - lowerLimit, 0f), ErosionRate * erosionForcing * bestWet * shoreEnergy * dt);
                if (erosion > 0f)
                {
                    _delta[i] -= erosion;
                    AddSedimentDownstream(i, x, z, transportFlow, erosion * SedimentTransport);
                }
            }
        }

        var maxColliderDelta = 0f;
        for (var i = 0; i < _heights.Length; i++)
        {
            _heights[i] += _delta[i];
            maxColliderDelta = Mathf.Max(maxColliderDelta, Mathf.Abs(_heights[i] - _collisionHeights[i]));
        }
        _collisionDirty = maxColliderDelta >= CollisionHeightThreshold || _collisionDirty;
    }

    private void AddSedimentDownstream(int index, float x, float z, Vector3 flow, float amount)
    {
        if (amount <= 0f || flow.LengthSquared() < 0.0001f) return;
        var dx = Mathf.Abs(flow.X) >= Mathf.Abs(flow.Z) ? (flow.X >= 0f ? 1 : -1) : 0;
        var dz = Mathf.Abs(flow.Z) > Mathf.Abs(flow.X) ? (flow.Z >= 0f ? 1 : -1) : 0;
        var cellX = Mathf.RoundToInt((x + TerrainSize.X * 0.5f) / _cellX);
        var cellZ = Mathf.RoundToInt((z + TerrainSize.Y * 0.5f) / _cellZ);
        var nextX = cellX + dx;
        var nextZ = cellZ + dz;
        if (nextX < 0 || nextX >= _side || nextZ < 0 || nextZ >= _side) return;
        _delta[nextZ * _side + nextX] += amount;
    }

    private void RefreshSurfaceMesh()
    {
        ComputeVerticesAndNormals();
        var arrays = new Godot.Collections.Array();
        arrays.Resize((int)Mesh.ArrayType.Max);
        arrays[(int)Mesh.ArrayType.Vertex] = _vertices;
        arrays[(int)Mesh.ArrayType.Normal] = _normals;
        arrays[(int)Mesh.ArrayType.TexUV] = _uvs;
        arrays[(int)Mesh.ArrayType.Color] = _colors;
        arrays[(int)Mesh.ArrayType.Index] = _indices;

        var mesh = new ArrayMesh();
        mesh.AddSurfaceFromArrays(Mesh.PrimitiveType.Triangles, arrays);
        if (_material != null) mesh.SurfaceSetMaterial(0, _material);
        if (_visual != null) _visual.Mesh = mesh;
    }

    private void ComputeVerticesAndNormals()
    {
        for (var z = 0; z < _side; z++)
        for (var x = 0; x < _side; x++)
        {
            var i = z * _side + x;
            var left = _heights[z * _side + Mathf.Max(x - 1, 0)];
            var right = _heights[z * _side + Mathf.Min(x + 1, _side - 1)];
            var back = _heights[Mathf.Max(z - 1, 0) * _side + x];
            var front = _heights[Mathf.Min(z + 1, _side - 1) * _side + x];
            var dx = (right - left) / Mathf.Max((x == 0 || x == _side - 1) ? _cellX : 2f * _cellX, 0.001f);
            var dz = (front - back) / Mathf.Max((z == 0 || z == _side - 1) ? _cellZ : 2f * _cellZ, 0.001f);
            _vertices[i] = new Vector3(-TerrainSize.X * 0.5f + x * _cellX, _heights[i], -TerrainSize.Y * 0.5f + z * _cellZ);
            _normals[i] = new Vector3(-dx, 1f, -dz).Normalized();
            _colors[i] = new Color(_wetness[i], 0f, 0f, 1f);
        }
    }

    private void RefreshCollisionShape()
    {
        if (_collision == null) return;
        ComputeVerticesAndNormals();
        var shape = new HeightMapShape3D
        {
            MapWidth = _side,
            MapDepth = _side,
            MapData = (float[])_heights.Clone()
        };
        _collision.Scale = new Vector3(_cellX, 1f, _cellZ);
        _collision.Shape = shape;
        Array.Copy(_heights, _collisionHeights, _heights.Length);
        _collisionDirty = false;
    }

    private static float Smooth01(float value)
    {
        var t = Mathf.Clamp(value, 0f, 1f);
        return t * t * (3f - 2f * t);
    }
}
