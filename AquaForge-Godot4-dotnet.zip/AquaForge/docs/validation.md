# Relatório de validação AquaForge

**Ambiente:** Godot 4.3 .NET, .NET SDK/runtime 8.0.100, Linux x86_64, execução headless.

## Compilação e execução

- `dotnet restore AquaForge.csproj`: concluído.
- `dotnet build AquaForge.csproj`: **0 erros**; 38 avisos de nulabilidade vêm principalmente dos arquivos upstream do Waterways .NET.
- Cena principal: `godot --headless --path . --quit-after 180` terminou com código de saída 0.

## Testes de física e terreno

`tests/terrain_physics_test.tscn` terminou com código de saída 0:

- leito profundo: `depth=1.50`, `wet=1.00`;
- empuxo/arrasto: corpo estabilizou em `y=-0.05`, `vy=-0.15` após 240 passos físicos;
- leito raso: `depth=0.80`, `wet=0.85`;
- margem seca após mover o colisor acima da lâmina.

`tests/shore_deformation_test.tscn` terminou com código de saída 0:

- erosão por ondas: altura do perfil `0.143 -> 0.066` em 5 segundos simulados;
- colisor HeightMap acompanha a malha deformada: `y=0.068` (diferença menor que 0.08 m);
- areia na faixa de espraiamento ficou úmida: `moisture=0.72`.

A deformação e a umidade foram verificadas consultando o terreno durante a simulação. O teste desloca terreno físico em runtime para confirmar atualização da batimetria no passo seguinte. Em um HeightMap/terreno externo, configure `WaterWorld.TerrainCollisionMask`; a deformação automática de malha pertence ao componente `ErodibleTerrain3D`.
