shader_type spatial;
render_mode blend_mix, depth_prepass_alpha, cull_disabled, diffuse_burley, specular_schlick_ggx;

// Shader original e econômico: duas ondas direcionais, Fresnel e espuma de crista.
// Para oceano distante, pode-se trocar o material pelo Boujie Water Shader.
uniform vec4 shallow_color : source_color = vec4(0.18, 0.66, 0.72, 0.94);
uniform vec4 deep_color : source_color = vec4(0.018, 0.16, 0.25, 0.98);
uniform vec4 foam_color : source_color = vec4(0.82, 0.95, 0.92, 0.95);
uniform vec2 flow_direction = vec2(1.0, 0.25);
uniform float wave_height : hint_range(0.0, 0.8) = 0.12;
uniform float wave_length : hint_range(1.0, 32.0) = 9.0;
uniform float wave_speed : hint_range(0.0, 4.0) = 1.0;
uniform float foam_amount : hint_range(0.0, 1.0) = 0.28;
uniform float opacity : hint_range(0.2, 1.0) = 0.94;
uniform float roughness : hint_range(0.02, 1.0) = 0.16;

varying float crest;
varying vec3 world_position;

void vertex() {
    vec2 d = normalize(flow_direction);
    float phase_a = dot(VERTEX.xz, d) * 6.2831853 / max(wave_length, 0.1) + TIME * wave_speed;
    float phase_b = dot(VERTEX.xz, normalize(vec2(-d.y, d.x) + vec2(0.24, 0.12))) * 6.2831853 / max(wave_length * 0.63, 0.1) - TIME * wave_speed * 0.73;
    float h = sin(phase_a) * wave_height + sin(phase_b) * wave_height * 0.22;
    VERTEX.y += h;
    crest = smoothstep(0.62, 0.97, sin(phase_a) * 0.5 + sin(phase_b) * 0.18 + 0.5);
    world_position = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}

void fragment() {
    float fresnel = pow(1.0 - clamp(dot(normalize(NORMAL), normalize(VIEW)), 0.0, 1.0), 4.0);
    float depth_tint = clamp(0.48 + UV.y * 0.08, 0.0, 1.0);
    vec3 base = mix(deep_color.rgb, shallow_color.rgb, depth_tint);
    float foam = smoothstep(1.0 - foam_amount, 1.0, crest);
    ALBEDO = mix(base, foam_color.rgb, foam * 0.72);
    METALLIC = 0.0;
    ROUGHNESS = roughness;
    SPECULAR = 0.75;
    ALPHA = mix(opacity, foam_color.a, foam * 0.6);
    EMISSION = shallow_color.rgb * fresnel * 0.06;
}
