shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx, cull_back;

// COLOR.r carrega a humidade persistente calculada por ErodibleTerrain3D.
uniform vec4 dry_sand : source_color = vec4(0.68, 0.53, 0.34, 1.0);
uniform vec4 wet_sand : source_color = vec4(0.25, 0.28, 0.24, 1.0);
uniform vec4 wash_foam : source_color = vec4(0.86, 0.91, 0.84, 1.0);
uniform float wet_roughness : hint_range(0.03, 0.8) = 0.2;
uniform float foam_strength : hint_range(0.0, 1.0) = 0.55;
uniform float time_scale : hint_range(0.0, 4.0) = 0.8;

varying float moisture;
varying vec3 local_position;

void vertex() {
    moisture = COLOR.r;
    local_position = VERTEX;
}

void fragment() {
    float wet = clamp(moisture, 0.0, 1.0);
    vec3 sand = mix(dry_sand.rgb, wet_sand.rgb, wet * 0.88);

    // Franja espumosa e irregular onde a água recua sobre a areia.
    float fringe = smoothstep(0.24, 0.46, wet) * (1.0 - smoothstep(0.63, 0.86, wet));
    float ripple = 0.5 + 0.5 * sin(local_position.x * 3.7 + local_position.z * 2.1 + TIME * time_scale);
    float foam = fringe * foam_strength * smoothstep(0.18, 0.82, ripple);

    ALBEDO = mix(sand, wash_foam.rgb, foam);
    ROUGHNESS = mix(0.94, wet_roughness, wet);
    SPECULAR = mix(0.08, 0.62, wet);
    METALLIC = 0.0;
}
