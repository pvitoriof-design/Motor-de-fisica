Dependências de terceiros incluídas sem histórico Git e sem demos pesadas:
- `waterways_net/` — projeto Waterways .NET, licença upstream em `waterways_net/LICENSE.upstream`.
- `boujie_water_shader/` — projeto Boujie, licença upstream em `boujie_water_shader/LICENSE.md`.
Repositórios originais constam no README principal. Atualize cada cópia a partir do upstream e revise licenças antes de redistribuir.
