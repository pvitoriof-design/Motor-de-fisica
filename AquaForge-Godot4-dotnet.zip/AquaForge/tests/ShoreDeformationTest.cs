using Godot;

namespace AquaForge.Tests;

/// <summary>Verifica erosão gradual e humidade persistente na zona de runup das ondas.</summary>
public partial class ShoreDeformationTest : Node3D
{
    public override async void _Ready()
    {
        var world = new WaterWorld { Name = "WaterWorld", TerrainCollisionMask = 1 };
        AddChild(world);
        AddChild(new WaterBody3D
        {
            Name = "TestBeachWater",
            Kind = WaterBody3D.WaterKind.Beach,
            Bounds = new Vector2(32, 32),
            SurfaceOffset = 0,
            WaveHeight = 0.45f,
            WaveLength = 3.2f,
            WaveSpeed = 1.4f,
            FlowDirection = new Vector3(1, 0, 0.15f),
            FlowSpeed = 0.12f,
            BuildVisualSurface = false
        });
        var shore = new ErodibleTerrain3D
        {
            Name = "TestShore",
            TerrainSize = new Vector2(32, 32),
            GridResolution = 32,
            BasinDepth = 2f,
            ShorelineRadius = 8f,
            OuterBeachRadius = 13f,
            BeachRise = 1.2f,
            MicroRelief = 0,
            ErosionRate = 0.04f,
            MaxErosionDepth = 0.5f,
            BeachRunup = 0.6f,
            WetSandBand = 0.8f,
            SimulationInterval = 0.1f,
            CollisionUpdateInterval = 0.3f
        };
        AddChild(shore);
        await ToSignal(GetTree(), SceneTree.SignalName.PhysicsFrame);

        var before = shore.GetHeightAtLocalXZ(9f, 0f);
        for (var frame = 0; frame < 300; frame++)
            await ToSignal(GetTree(), SceneTree.SignalName.PhysicsFrame);
        var after = shore.GetHeightAtLocalXZ(9f, 0f);
        var wetSand = shore.GetMoistureAtLocalXZ(12f, 0f);

        if (after >= before - 0.005f)
        {
            GD.PushError($"FAIL ShoreDeformationTest: erosão não alterou o perfil ({before:F3} -> {after:F3}).");
            GetTree().Quit(1);
            return;
        }
        GD.Print($"PASS erosão por ondas: altura {before:F3} -> {after:F3} em 5 s simulados");

        var worldPosition = shore.ToGlobal(new Vector3(9f, 0f, 0f));
        if (!world.TryGetTerrainHeight(worldPosition, 0f, null, out var collisionHeight))
        {
            GD.PushError("FAIL ShoreDeformationTest: o colisor deformável não respondeu ao raycast.");
            GetTree().Quit(1);
            return;
        }
        if (Mathf.Abs(collisionHeight - after) > 0.08f)
        {
            GD.PushError($"FAIL ShoreDeformationTest: malha e colisor divergiram ({after:F3} / {collisionHeight:F3}).");
            GetTree().Quit(1);
            return;
        }
        GD.Print($"PASS colisor acompanha o relevo: y={collisionHeight:F3}");

        if (wetSand < 0.2f)
        {
            GD.PushError($"FAIL ShoreDeformationTest: faixa de areia no runup não ficou úmida (moisture={wetSand:F2}).");
            GetTree().Quit(1);
            return;
        }
        GD.Print($"PASS areia molhada/espuma de recuo: moisture={wetSand:F2}");
        GetTree().Quit();
    }
}
