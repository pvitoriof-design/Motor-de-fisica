using Godot;
using System.Threading.Tasks;

namespace AquaForge.Tests;

/// <summary>Regressão headless: testa leito profundo, margem rasa e terreno movido em runtime.</summary>
public partial class TerrainPhysicsTest : Node3D
{
    public override async void _Ready()
    {
        var world = new WaterWorld { Name = "WaterWorld", TerrainCollisionMask = 1 };
        AddChild(world);
        AddChild(new WaterBody3D
        {
            Name = "TestLake",
            BuildVisualSurface = false,
            Bounds = new Vector2(30, 30),
            WaveHeight = 0,
            FlowSpeed = 0
        });

        var ground = new StaticBody3D { Name = "MovableTestTerrain", CollisionLayer = 1, CollisionMask = 1, Position = new Vector3(0, -2, 0) };
        ground.AddChild(new CollisionShape3D { Shape = new BoxShape3D { Size = new Vector3(20, 1, 20) } });
        AddChild(ground);

        await ToSignal(GetTree(), SceneTree.SignalName.PhysicsFrame);
        await ToSignal(GetTree(), SceneTree.SignalName.PhysicsFrame);

        var point = new Vector3(0, -0.1f, 0);
        if (!world.TrySample(point, out var deep)) Fail("Esperava água sobre o leito profundo.");
        else if (deep.Depth < 1.4f || deep.WetFactor < 0.99f) Fail($"Profundidade inesperada no leito: depth={deep.Depth:F2}, wet={deep.WetFactor:F2}");
        else GD.Print($"PASS leito profundo: depth={deep.Depth:F2}, wet={deep.WetFactor:F2}");

        var floatingBody = new RigidBody3D { Name = "PhysicsProbe", Position = new Vector3(5, 1.2f, 0), Mass = 12f };
        floatingBody.AddChild(new CollisionShape3D { Shape = new BoxShape3D { Size = new Vector3(0.8f, 0.5f, 0.8f) } });
        floatingBody.AddChild(new BuoyantBody3D
        {
            Name = "Buoyancy",
            WaterWorldPath = new NodePath("../../WaterWorld"),
            HalfExtents = new Vector3(0.35f, 0.2f, 0.35f),
            SampleGrid = 3,
            Buoyancy = 1.15f
        });
        AddChild(floatingBody);
        for (var frame = 0; frame < 240; frame++)
            await ToSignal(GetTree(), SceneTree.SignalName.PhysicsFrame);
        if (floatingBody.GlobalPosition.Y < -0.35f || Mathf.Abs(floatingBody.LinearVelocity.Y) > 2.0f)
            Fail($"Corpo não estabilizou na água: y={floatingBody.GlobalPosition.Y:F2}, vy={floatingBody.LinearVelocity.Y:F2}");
        else GD.Print($"PASS empuxo/arrasto: y={floatingBody.GlobalPosition.Y:F2}, vy={floatingBody.LinearVelocity.Y:F2}");

        // Topo da caixa fica em -0.8m: água rasa, com atenuação física.
        ground.Position = new Vector3(0, -1.3f, 0);
        await ToSignal(GetTree(), SceneTree.SignalName.PhysicsFrame);
        await ToSignal(GetTree(), SceneTree.SignalName.PhysicsFrame);
        if (!world.TrySample(point, out var shallow)) Fail("A amostra de água rasa desapareceu.");
        else if (shallow.Depth < 0.65f || shallow.WetFactor >= 0.99f) Fail($"Água rasa não atenuada: depth={shallow.Depth:F2}, wet={shallow.WetFactor:F2}");
        else GD.Print($"PASS leito raso: depth={shallow.Depth:F2}, wet={shallow.WetFactor:F2}");

        // O terreno sobe acima da lâmina; a mesma coordenada deve deixar de ser molhada.
        ground.Position = new Vector3(0, 1.0f, 0);
        await ToSignal(GetTree(), SceneTree.SignalName.PhysicsFrame);
        await ToSignal(GetTree(), SceneTree.SignalName.PhysicsFrame);
        if (world.TrySample(point, out _)) Fail("Terreno acima da lâmina ainda foi classificado como água.");
        else GD.Print("PASS margem seca após mover o terreno em runtime");

        GetTree().Quit();
    }

    private void Fail(string message)
    {
        GD.PushError("FAIL TerrainPhysicsTest: " + message);
        GetTree().Quit(1);
    }
}
